﻿
namespace semana_14
{
    class Programsemana_14
    {
        static void Main(string[] args)
        {
            int[] array = new int[12];
            int suma = 0;
            Console.WriteLine("Ingrese 12 números:");

            for (int i = 0; i < 12; i++)
            {
                Console.Write($"Número {i + 1}: ");
                array[i] = Convert.ToInt32(Console.ReadLine());
            }
            while (true)
            {
                Console.ReadLine();
                Console.WriteLine("-------------------------------------");
                Console.WriteLine("MENU");
                Console.WriteLine("1. suma de los números");
                Console.WriteLine("2. promedio de los números");
                Console.WriteLine("3. Ordenar de menor a mayor");
                Console.WriteLine("4. Ordenar de mayor a menor");
                Console.WriteLine("5. Cambiar tamaño de arreglo");
                Console.WriteLine("-------------------------------------");
                int opcion = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        foreach (int numero in array)
                        {
                            suma += numero;
                        }
                        Console.WriteLine($"La suma es: {suma}");
                        break;
                    case 2:
                        double promedio = (double)suma / 12;
                        Console.WriteLine($"El promedio de los números es: {promedio}");
                        break;
                    case 3:
                        Console.WriteLine("Los numeros de menor a mayor son:");
                        Array.Sort(array);
                        foreach (int num in array)
                        {
                            Console.WriteLine(num + " ");
                        }
                        Console.ReadKey();
                        break;
                    case 4:
                        Console.WriteLine("Los numeros de mayor a menor son:");
                        Array.Sort(array);
                        Array.Reverse(array);
                        foreach (int num in array)
                        {
                            Console.WriteLine(num + " ");
                        }
                        Console.ReadKey();
                        break;
                    case 5:
                        Array.Resize(ref array, array.Length + 2);

                        foreach (var pallet in array)
                        {
                            Console.WriteLine($"-- {pallet}");
                        }
                        break;
                        case 6:
                        string splitnum = String.Join(",", array);
                        string[] numarray = splitnum.Split(',');
                        foreach (string num in numarray)
                        {
                            Console.WriteLine(num);
                        }
                        Console.ReadKey();
                        break;
                }

            }


        }
    }
}
