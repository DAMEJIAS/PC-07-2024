﻿
public class Mejia
{
    // propiedades de la clase 
    int siu;
    int edad;
    string nombre;
    public static void Main()
    {
        menu();
        
    }
    Mejia(int siu, int edad, string nombre)
    {
        this.edad = edad;
        this.nombre = nombre ;
        this.siu = siu;
    }
    // metodo de la clase 
   public void show()
    {
         Console.WriteLine(this.siu);
        Console.WriteLine(this.edad);
        Console.WriteLine(this.nombre);
    }
    public void pedirdatos()
{
     Console.WriteLine("Ingrese el año");
        this.siu = int.Parse(Console.ReadLine()); 
        Console.WriteLine("Ingrese su edad");
        this.edad = int.Parse(Console.ReadLine()); 
        Console.WriteLine("Ingrese su nombre");
        this.nombre = Console.ReadLine();

 
}
 public static void menu()
{
    Mejia m = new Mejia(0, 0,"");
    while(true)
    {
    
         Console.WriteLine("-----------------------------");
         Console.WriteLine("Seleccione una opcion");
         Console.WriteLine(" 1. ingresar valores ");
         Console.WriteLine(" 2. mostrar valores ");
         Console.WriteLine(" 3. salir del progremam ");
         Console.WriteLine("-----------------------------");
         int opcion = int.Parse(Console.ReadLine());


        switch(opcion)
        {
            case 1:
            m.pedirdatos();
            break;
            case 2:
            m.show();
            break;
            case 3:
             Console.WriteLine("Feliz día");
            break;
        }
    }   
}
  }
